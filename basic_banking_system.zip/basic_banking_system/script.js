// Created Using Easy HTML v1.4.7
// https://play.google.com/store/apps/details?id=ak.andro.easyhtml


   function setCustomer() {
    for (let i = 0; i < custData.length; i++) {
    let customer = {
        account_no: custData[i].account_no,
        name: custData[i].name,
        email: custData[i].email,
        balance: custData[i].balance
    }
    localStorage.setItem(custData[i].account_no, JSON.stringify(customer));
}
}
function loader(){
    setCustomer();
}
window.onload = loader;
const tableRow = document.getElementById("table-row");

//let allCustomers = [];

function getCustomer() {
    tableRow.innerHTML = "";
    for (let i = 0; i < custData.length; i++) {
        let customer = JSON.parse(localStorage.getItem(custData[i].account_no));
        renderData(customer);
    }
}

function renderData(customer) {
    let listCustomers = `
        <tr>
            <td>${customer.account_no}</td>
            <td>${customer.name}</td>
            <td>${customer.email}</td>
            <td>${customer.balance}</td>
            <td><button type="buttpn"  class="btn btn-info" id="${customer.account_no}" data-toggle="modal" data-target="#popupcustomerdetails">Details</Button></td>        
        </tr>    
        `;
    tableRow.insertAdjacentHTML('beforeend', listCustomers);


}

function btnDetails() {
    for (let i = 0; i < custData.length; i++) {
        let btnDetail = document.getElementById(`${custData[i].account_no}`);
        btnDetail.onclick = function () {
            renderUserInfo(custData[i]);
        }
    }
}

function renderUserInfo(userdata) {
    let user_acc = document.getElementById('prf-acc-no');
    let user_name = document.getElementById('prf-name');
    let user_email = document.getElementById('prf-email');
    let user_balance = document.getElementById('prf-balance');
    let user_nameCard = document.getElementById("prf-name-card");
    user_acc.innerHTML = userdata.account_no;
    user_name.innerHTML = userdata.name;
    user_email.innerHTML = userdata.email;
    user_balance.innerHTML = userdata.balance;
    user_nameCard.innerHTML = userdata.name;
}


function loader() {
    getCustomer();
    btnDetails();
}

window.onload = loader;
let custData = [{
   "account_no": "8416305161",
    "name": "Abhay Vishwakarma",
    "email": "abhay@gmail.com",
    "balance": "8757.00"
  }, {
    "account_no": "0745051928",
    "name": "Shailesh Mishra",
    "email": "shailesh@pinterest.com",
    "balance": "8311.54"
  }, {
    "account_no": "9641004190",
    "name": "Devesh Yadav",
    "email": "devesh@histats.com",
    "balance": "2324.79"
  }, {
    "account_no": "9784514362",
    "name": "Aditya Shinde",
    "email": "aditya@hotmail.com",
    "balance": "8587.86"
  }, {
    "account_no": "3026504866",
    "name": "Nikhil Chaube",
    "email": "nikhil@yahoo.com",
    "balance": "6438.80"
  }, {
    "account_no": "3656041741",
    "name": "Akash Gawai",
    "email": "akash@outlook.net",
    "balance": "1052.84"
  }, {
    "account_no": "4357994632",
    "name": "Vishal pandey",
    "email": "vishal@gmail.com",
    "balance": "9952.50"
  }, {
    "account_no": "0715122916",
    "name": "Akash Bhagne",
    "email": "akash@live.in",
    "balance": "9087.60"
  }, {
    "account_no": "5611890172",
    "name": "Prince Singh",
    "email": "prince@gmail.com",
    "balance": "2251.32"
  }, {
    "account_no": "4854295384",
    "name": "Samiksha Jaitapkar",
    "email": "samiksha@live.com",
    "balance": "5680.26"
  }];

let transactionHistoryTableData = document.getElementById("transaction_history_table_data");
let tHistory = JSON.parse(localStorage.getItem('transactionHistory'));



//   this code is for transaction History here begins
console.table(tHistory);
function fetchListHistory() {
    transactionHistoryTableData.innerHTML = ""       
   for (let i = 0; i < tHistory.length; i++) {
       let historydata = JSON.parse(localStorage.getItem(tHistory[i]));
       renderListHistory(historydata);
   }

   }

 function renderListHistory(historydata)
 {
 let transactiondata = `<tr>
                           <td>${historydata.transaction_id}</td>
                           <td>${historydata.sender_name}</td>
                           <td>${historydata.receiver_name}</td>
                           <td>${historydata.trans_amount}</td>
                           <td>${historydata.timestamp}</td>
                       </tr>`
 transactionHistoryTableData.insertAdjacentHTML( 'beforeend' , transactiondata );
}
 

//   transaction history data code ends here


function loaders() {
   fetchListHistory();
}

window.onload = loaders() ;
let custLists = document.getElementById("cs_lists");
let crLists = document.getElementById("cr_lists");
let sEmail = document.getElementById("s_email");
let rEmail = document.getElementById("r_email");
let transferAmount = document.getElementById("transfer_amount");
let submit = document.getElementById("submit");
let msg = document.getElementById("msg");



let transactionHistory = JSON.parse(localStorage.getItem('transactionHistory'));
if(transactionHistory == null){
    transactionHistory = [];
}
document.querySelector('#cList_s_name').addEventListener('input', optionSelects);
document.querySelector('#cList_r_name').addEventListener('input', optionSelectr);

// fuction to fetch customer list
function getCustomerList() {
    //custLists.innerHTML = "";
    for (let i = 0; i < custData.length ; i++) {
        let customer = JSON.parse(localStorage.getItem(custData[i].account_no));
        renderDataList(customer);
        renderRDataList(customer);
    }

}

// funtion to put fetched list into datalist for sender 
function renderDataList(customer) {
    let listCustomers = `<option value="${customer.account_no}"></option>`;
    custLists.insertAdjacentHTML('beforeend', listCustomers);
}

// funtion to put fetched list into datalist for receiver
function renderRDataList(customer) {
    let listRCustomers = `<option value="${customer.account_no}"></option>`;
    crLists.insertAdjacentHTML('beforeend', listRCustomers);
}

// function to get emailid automatically for sender
function optionSelects(e){
    let input = e.target;
    val = input.value;
    list = input.getAttribute('list');
    options = document.getElementById(list).childNodes;
    for(let i = 0; i < options.length; i++) {
        autofillInfos(val);
        break;
    }
}

// function to get emailid automatically for receiver
function optionSelectr(e){
    let input = e.target;
    val = input.value;
    list = input.getAttribute('list');
    options = document.getElementById(list).childNodes;
    for(let i = 0; i < options.length; i++) {
        autofillInfor(val);
        break;
    }
}

// function to put emailid into form automatically for sender
function autofillInfos(id){
    let idx = custData.findIndex(x => x.account_no == id);
    sEmail.value = custData[idx].email;
}

// function to put emailid into form automatically for receiver
function autofillInfor(id){
    let idx = custData.findIndex(x => x.account_no == id);
    rEmail.value = custData[idx].email;
}

  // function for amount transfer
  submit.addEventListener("click", function amountTransferFunc() {

    let s = document.getElementById("cList_s_name").value;
    let r = document.getElementById("cList_r_name").value;
    let sender = JSON.parse(localStorage.getItem(s));
    let receiver = JSON.parse(localStorage.getItem(r));
    if( s == sender.account_no && r == receiver.account_no){
        if(sender.balance > transferAmount.value && sender.account_no != receiver.account_no){
            let bal1 = parseInt(sender.balance) - parseInt(transferAmount.value);
            let customer_s = {
                account_no: sender.account_no,
                name: sender.name,
                email: sender.email,
                balance: bal1
            }
            localStorage.setItem(sender.account_no, JSON.stringify(customer_s));

            let bal2 = parseInt(receiver.balance) + parseInt(transferAmount.value);
            let customer_r = {
                account_no: receiver.account_no,
                name: receiver.name,
                email: receiver.email,
                balance: bal2
            }
            localStorage.setItem(receiver.account_no, JSON.stringify(customer_r));


            msg.innerHTML = `<div class="alert alert-success" role="alert" >
            Your transaction is Successful.
          </div>`

        // this code is to set list of transaction history
        let tid = Math.floor(100000 + Math.random() * 900000);
        let currentDate = new Date().toLocaleString("en-US", {timeZone: 'Asia/Kolkata'});
        transactionHistory.push(tid);
          let trans_hist = {
              transaction_id: tid,
              sender_name: sender.name,
              receiver_name: receiver.name,
              trans_amount: transferAmount.value,
              timestamp: currentDate             
          }
          localStorage.setItem(tid, JSON.stringify(trans_hist));
        //   code for transaction history ends
        localStorage.setItem('transactionHistory', JSON.stringify(transactionHistory));

    
        }
        else{
            msg.innerHTML = `<div class="alert alert-danger" role="alert" >
            Your transaction can not be executed.
          </div>
          `
          
        }
    }
   
    document.getElementById("form-money-transfer").reset();
   
})

setInterval(() => {
    msg.innerHTML = "";
}, 5000);

function loaders() {
    getCustomerList();
}

window.onload = loaders();
